import React, { Component } from 'react';
import './App.css';
import Home from './home';
import Footer from './footer';
import Header from './header';


class App extends Component 
{
	
  	render()
 {
    return (

			<div >				
					<Header/>
					<Home/>
					<Footer/>	         			
      </div>
    );
	}
	

}
export default App;



