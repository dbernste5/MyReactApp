import React, { Component, Fragment } from 'react';

class SignUp extends Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            username: '',
            password: '',
            firstName: '',
            lastName: '',
            email: '',
            phone: ''
        };
    }

    form()
    {
        return(
        <form id="signUpForm" onSubmit={this.onSubmitForm}>
            <label>First Name</label><br/>
            <input id="firstName" type="text" onChange={this.onChangeFirst}></input><br/><br/>
            <label>Last Name</label><br/>
            <input id="lastName" type="text"></input><br/><br/>
            <label>Email</label><br/>
            <input id="email" type="text"></input><br/><br/>
            <label>Phone Number</label><br/>
            <input id="phone" type="text"></input><br/><br/>
            <label>Username</label><br/>
            <input id="username" type="text"></input><br/><br/>
            <label>Password</label><br/>
            <input id="password" type="text"></input><br/><br/>
            <label>Confirm Password</label><br/>
            <input id="confirmPassword" type="text"></input><br/><br/>
            <button id= "signUpSubmit" type="submit">Submit</button>
        </form>)
    }
    onChangeFirst()
    {
        this.
    }
    onSubmitForm()
    {

        fetch("/user", {
            method: "POST",
            body: this.state
        });
    }
    render()
    {
        return(
            <Fragment>
                {this.form()}
            </Fragment>
        )
    }
}
export default SignUp